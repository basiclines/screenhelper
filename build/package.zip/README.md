screenhelper
============

A webapp application that give some basic information about the device screen